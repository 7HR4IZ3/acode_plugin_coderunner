/// <reference path="acode.d.ts" />
