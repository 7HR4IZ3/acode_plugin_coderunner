import time

for i in range(5):
  print(i)
  time.sleep(0.5)